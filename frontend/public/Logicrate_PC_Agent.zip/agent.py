import os
import time
import json
import shutil
import hashlib
import threading
import requests
import pdfplumber
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# ─── Load Config ──────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")

def load_config():
    if not os.path.exists(CONFIG_PATH):
        print("Error: config.json not found!")
        return None
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

CONFIG = load_config()
if not CONFIG:
    exit(1)

API_KEY = CONFIG.get("API_KEY")
API_URL = CONFIG.get("API_URL", "http://127.0.0.1:8000")
WATCH_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, CONFIG.get("WATCH_DIR", "./weighbridge_pdfs")))
ARCHIVE_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, CONFIG.get("ARCHIVE_DIR", "./processed_archive")))

os.makedirs(WATCH_DIR, exist_ok=True)
os.makedirs(ARCHIVE_DIR, exist_ok=True)

# ─── Utility Functions ───────────────────────────────────────────────────

def wait_for_file_stability(file_path: str, max_retries=10, delay=1.0) -> bool:
    """Ensure file size is stable (not locked/writing) before processing."""
    previous_size = -1
    retries = 0
    while retries < max_retries:
        try:
            current_size = os.path.getsize(file_path)
            if current_size == previous_size and current_size > 0:
                time.sleep(1) # Give it an extra second after stability
                return True
            previous_size = current_size
        except OSError:
            pass
        retries += 1
        time.sleep(delay)
    return False

def generate_file_hash(file_path: str) -> str:
    md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            md5.update(chunk)
    return md5.hexdigest()

def extract_text(file_path: str) -> str:
    extracted_text = ""
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    extracted_text += text + "\n"
    except Exception as e:
        print(f"Extraction error on {file_path}: {e}")
    return extracted_text.strip()

# ─── Processing Logic ────────────────────────────────────────────────────

def process_file(file_path: str):
    filename = os.path.basename(file_path)
    print(f"[{time.strftime('%H:%M:%S')}] Detected: {filename}")
    
    if not wait_for_file_stability(file_path):
        print(f"[{time.strftime('%H:%M:%S')}] Error: File {filename} remains locked/unstable.")
        return

    # Hash file
    file_hash = generate_file_hash(file_path)
    
    # Extract Text
    print(f"[{time.strftime('%H:%M:%S')}] Extracting text from {filename}...")
    raw_text = extract_text(file_path)
    
    if not raw_text:
        print(f"[{time.strftime('%H:%M:%S')}] Error: No text found in {filename}. Ensure it is a valid text PDF.")
        # Move to archive with _failed suffix so it doesn't try again repeatedly
        shutil.move(file_path, os.path.join(ARCHIVE_DIR, f"failed_{filename}"))
        return

    # Upload to Cloud
    payload = {
        "file_name": filename,
        "file_hash": file_hash,
        "raw_text": raw_text
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    if API_KEY and API_KEY != "YOUR-API-KEY-HERE":
        headers["x-api-key"] = API_KEY

    print(f"[{time.strftime('%H:%M:%S')}] Uploading {filename} to {API_URL}/api/upload...")
    try:
        response = requests.post(f"{API_URL}/api/upload", json=payload, headers=headers)
        if response.status_code in [200, 201, 202]:
            print(f"[{time.strftime('%H:%M:%S')}] Success: {filename} uploaded.")
            # Move to archive
            shutil.move(file_path, os.path.join(ARCHIVE_DIR, filename))
        else:
            print(f"[{time.strftime('%H:%M:%S')}] Server Error ({response.status_code}): {response.text}")
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] Connection Error: {str(e)}")

# ─── Watchdog Observer ───────────────────────────────────────────────────

class PDFHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory and event.src_path.lower().endswith(".pdf"):
            # Run processing in a separate thread so we don't block the file watcher
            threading.Thread(target=process_file, args=(event.src_path,)).start()

def main():
    print(f"Starting Logicrate PC Agent...")
    print(f"API URL: {API_URL}")
    print(f"Watching: {WATCH_DIR}")
    print(f"Archiving to: {ARCHIVE_DIR}")
    
    event_handler = PDFHandler()
    observer = Observer()
    observer.schedule(event_handler, path=WATCH_DIR, recursive=False)
    observer.start()
    
    # Process any PDFs that already exist in the directory upon startup
    existing_files = [f for f in os.listdir(WATCH_DIR) if f.lower().endswith('.pdf')]
    for file in existing_files:
        threading.Thread(target=process_file, args=(os.path.join(WATCH_DIR, file),)).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

if __name__ == "__main__":
    main()
